// Fill out your copyright notice in the Description page of Project Settings.


#include "CustomPlayer.h"

#include "GameFramework/CharacterMovementComponent.h"
#include "Sound/SoundCue.h"
#include "Kismet/GameplayStatics.h"

// Sets default values
ACustomPlayer::ACustomPlayer()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	
	Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("Camera"));
	Camera->SetupAttachment(GetRootComponent());

	PlayerHands = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PlayerHands"));
	PlayerHands->SetupAttachment(GetRootComponent());

	PlayerHands->SetCastShadow(false);

	//Var Defaults
	bRevertTilt = false;
	CachedAxis = 0;
	StartingRollValue = 0;
	bHandAnimPlaying = false;
	bPlayedFootstep = false;
	GetCharacterMovement()->MaxWalkSpeed = 200;
}

void ACustomPlayer::TimelineProgress(float Value)
{
	FRotator NewRot = FMath::Lerp(StartRot, EndRot, Value);
	Camera->SetRelativeRotation(FRotator(Camera->GetRelativeRotation().Pitch, Camera->GetRelativeRotation().Yaw, NewRot.Roll));
}

void ACustomPlayer::HandTimelineProgress(float Value)
{
	FVector NewLoc = FMath::Lerp(StartLoc, EndLoc, Value);
	PlayerHands->SetWorldLocation(FVector(PlayerHands->GetComponentLocation().X, PlayerHands->GetComponentLocation().Y, NewLoc.Z));
	//Match up footsteps with the bobbing animation. -1 equals the lowest point of the bob

	bool bAtLowestPointOfAnim = FMath::IsNearlyEqual(Value, -1.f, .1f);
	if (!bPlayedFootstep && bAtLowestPointOfAnim)
	{
		PlayFootstep();
		bPlayedFootstep = true;
	} else if (!bAtLowestPointOfAnim)
	{
		bPlayedFootstep = false;
	}
	
}

// Called when the game starts or when spawned
void ACustomPlayer::BeginPlay()
{
	Super::BeginPlay();

	StartingRollValue = Camera->GetComponentRotation().Roll;
	
}

// Called every frame
void ACustomPlayer::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	
	CustomCameraUsePawnRotation();

	CurveTimeline.TickTimeline(DeltaTime);
	HandTimeline.TickTimeline(DeltaTime);
}

// Called to bind functionality to input
void ACustomPlayer::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	
	PlayerInputComponent->BindAxis("MoveForward", this, &ACustomPlayer::MoveForward);
	PlayerInputComponent->BindAxis("MoveRight", this, &ACustomPlayer::MoveRight);
	PlayerInputComponent->BindAxis("MoveMouseX", this, &ACustomPlayer::MouseMoveX);
	PlayerInputComponent->BindAxis("MoveMouseY", this, &ACustomPlayer::MouseMoveY);

	PlayerInputComponent->BindAction("Interact", IE_Pressed, this, &ACustomPlayer::Interact);
}

void ACustomPlayer::MoveForward(float Axis)
{
	if (Controller != nullptr)
	{
		AddMovementInput(GetActorForwardVector(), Axis);
		
		HandAnimationSetup(Axis);
	}
}

void ACustomPlayer::MoveRight(float Axis)
{
	if (Controller != nullptr)
	{
		AddMovementInput(GetActorRightVector(), Axis);
		
		MoveCameraTilt(Axis);
	}
}

void ACustomPlayer::MouseMoveX(float Axis)
{
	AddControllerYawInput(Axis);
}

void ACustomPlayer::MouseMoveY(float Axis)
{
	AddControllerPitchInput(Axis);
}

void ACustomPlayer::Interact()
{
	
}


void ACustomPlayer::MoveCameraTilt(float Axis)
{
	if (Axis != 0)
	{
		StartTimeline(Axis, RollTiltOffset);
		bRevertTilt = true;
		CachedAxis = Axis;
	} else if (Axis == 0 && bRevertTilt)
	{
		StartTimeline(Axis, RollTiltOffset);
		bRevertTilt = false;
	}
}

void ACustomPlayer::HandAnimationSetup(float Axis)
{
	//Only want the animation to play once, then continue on forever
	if (!bHandAnimPlaying)
	{
		StartHandTimeline(Axis, ZOffset);
		bHandAnimPlaying = true;
	}
	//Set the playback rate to be faster during movement
	if (Axis != 0)
	{
		HandTimeline.SetPlayRate(1);
	} else if (Axis == 0)
	{
		HandTimeline.SetPlayRate(.5);
	}
}

void ACustomPlayer::StartTimeline(float Axis, float TiltAmount)
{
	if (CurveFloat)
	{
		FOnTimelineFloat TimelineProgress;
		TimelineProgress.BindUFunction(this, FName("TimelineProgress"));
		CurveTimeline.AddInterpFloat(CurveFloat, TimelineProgress);
		CurveTimeline.SetLooping(false);

		StartRot = EndRot = Camera->GetRelativeRotation();
		
		if (Axis != 0) //Tilting the camera
		{
			EndRot.Roll += TiltAmount * Axis;
		} else //Reverting the tilt
		{
			EndRot.Roll = StartingRollValue;
		}
		EndRot.Roll = FMath::Clamp(EndRot.Roll, -TiltAmount, TiltAmount);
		
		CurveTimeline.PlayFromStart();
	}
}

void ACustomPlayer::StartHandTimeline(float Axis, float ZAmount)
{
	if (HandFloat)
	{
		FOnTimelineFloat TimelineProgress;
		TimelineProgress.BindUFunction(this, FName("HandTimelineProgress"));
		HandTimeline.AddInterpFloat(HandFloat, TimelineProgress);
		HandTimeline.SetLooping(true);

		StartLoc = EndLoc = PlayerHands->GetComponentLocation();
		EndLoc.Z += ZAmount;
		HandTimeline.PlayFromStart();
	}
}

void ACustomPlayer::PlayFootstep()
{
	bool bIsMoving = GetVelocity().Size() != 0;
	if (FootstepSound && bIsMoving)
	{
		//Give a slight change to each footstep sound. Not too much to allow this sound to stay in the background
		FootstepSound->PitchMultiplier = FMath::FRandRange(.7f, 1.3f);
		UGameplayStatics::PlaySound2D(this, FootstepSound);
	}
}

void ACustomPlayer::InRangeOfInteractable()
{
	
}



