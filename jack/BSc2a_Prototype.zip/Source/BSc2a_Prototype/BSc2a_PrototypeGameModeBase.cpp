// Copyright Epic Games, Inc. All Rights Reserved.


#include "BSc2a_PrototypeGameModeBase.h"

