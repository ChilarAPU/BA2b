// Fill out your copyright notice in the Description page of Project Settings.


#include "EndGoal.h"



#include "CustomPlayer.h"
#include "Components/BoxComponent.h"
#include "Components/SphereComponent.h"

// Sets default values
AEndGoal::AEndGoal()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	RootComp = CreateDefaultSubobject<USceneComponent>(TEXT("RootComp"));
	SetRootComponent(RootComp);

	ComputerMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("ComputerMesh"));
	ComputerMesh->SetupAttachment(RootComp);

	CollideTrigger = CreateDefaultSubobject<UBoxComponent>(TEXT("Attemp"));
	CollideTrigger->SetupAttachment(RootComp);

	CollideTrigger->OnComponentBeginOverlap.AddDynamic(this, &AEndGoal::OnOverlapBegin);
}

// Called when the game starts or when spawned
void AEndGoal::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AEndGoal::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AEndGoal::OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComponent,
	int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	ACustomPlayer* Player = Cast<ACustomPlayer>(OtherActor);
	if (Player)
	{
		Player->InRangeOfInteractable();
	}
}

